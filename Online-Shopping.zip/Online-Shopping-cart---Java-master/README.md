# Online-Shopping-cart---Java
This is a simple online shopping system for laptops built using Java. There are two kinds of users. Admin and normal. Admin users have special 
priviliges like creating a new item, adding an existing item or deleting an item. Whereas normal users can only use this to look up items
, add items to the cart and purchase them.

The program runs with the Main class. 
user : fancy
password: fancy
